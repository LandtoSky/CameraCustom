//
//  CameraFocusIndicator.h
//  CameraWithAVFoundation
//
//  Created by Gabriel Alvarado on 1/25/15.
//  Copyright (c) 2015 Gabriel Alvarado. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CameraFocalReticule : UIView

@end
