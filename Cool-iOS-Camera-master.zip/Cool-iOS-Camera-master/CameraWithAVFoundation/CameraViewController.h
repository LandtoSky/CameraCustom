//
//  CameraViewController.h
//  CameraWithAVFoundation
//
//  Created by Gabriel Alvarado on 4/16/14.
//  Copyright (c) 2014 Gabriel Alvarado. All rights reserved.
//
#import <UIKit/UIKit.h>

@interface CameraViewController : UIViewController

@end
